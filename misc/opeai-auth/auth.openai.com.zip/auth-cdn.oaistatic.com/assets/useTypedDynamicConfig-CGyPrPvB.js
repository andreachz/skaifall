import{s as o}from"./useAppNameEnum-B_RCZZaG.js";function r(a,n,e){const c=o.useDynamicConfig(a),s=n.safeParse(c.value);return s.success?s.data:e}export{r as u};
//# sourceMappingURL=useTypedDynamicConfig-CGyPrPvB.js.map
