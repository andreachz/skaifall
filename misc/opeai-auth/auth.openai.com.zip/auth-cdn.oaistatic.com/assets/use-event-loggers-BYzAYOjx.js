import{r as t}from"./index-DjeUAv9f.js";import{n as e}from"./noop-DX6rZLP_.js";const o=t.createContext(new Proxy({},{get:()=>e}));function s(){return t.useContext(o)}export{o as E,s as u};
//# sourceMappingURL=use-event-loggers-BYzAYOjx.js.map
