import{j as o}from"./index-DjeUAv9f.js";import{c as r}from"./index-npON1Cka.js";import{s as m}from"./UnstyledButton.module-B7YD8bFL.js";const p=({className:s,...t})=>o.jsx("button",{className:r(m.root,s),...t});export{p as U};
//# sourceMappingURL=UnstyledButton-ByeG5n5X.js.map
