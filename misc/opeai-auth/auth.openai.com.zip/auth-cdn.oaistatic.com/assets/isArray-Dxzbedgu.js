var r=Array.isArray;export{r as i};
//# sourceMappingURL=isArray-Dxzbedgu.js.map
