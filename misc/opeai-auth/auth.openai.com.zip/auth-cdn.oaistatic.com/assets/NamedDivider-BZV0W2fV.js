import{j as s}from"./index-DjeUAv9f.js";const n="_root_12co7_1",a="_line_12co7_7",t="_name_12co7_12",e={root:n,line:a,name:t},c=({children:o})=>s.jsxs("div",{className:e.root,children:[s.jsx("div",{className:e.line}),s.jsx("div",{className:e.name,children:o}),s.jsx("div",{className:e.line})]});export{c as N};
//# sourceMappingURL=NamedDivider-BZV0W2fV.js.map
