import{M as a}from"./utils-BGG_ggsw.js";import{z as e}from"./useAppNameEnum-B_RCZZaG.js";function s(t){return new a(t).getCountries()}const n=e.enum(["email","phone_number"]),m=n.enum.email,i=e.object({value:e.string(),kind:n});export{m as D,n as U,i as a,s as g};
//# sourceMappingURL=username-DImii0_h.js.map
