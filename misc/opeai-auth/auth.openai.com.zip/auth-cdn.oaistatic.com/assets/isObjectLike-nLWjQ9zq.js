function e(t){return t!=null&&typeof t=="object"}export{e as i};
//# sourceMappingURL=isObjectLike-nLWjQ9zq.js.map
