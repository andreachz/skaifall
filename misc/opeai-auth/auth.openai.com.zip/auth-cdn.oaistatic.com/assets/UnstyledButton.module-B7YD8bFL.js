const o="_root_l0v7g_1",t={root:o};export{t as s};
//# sourceMappingURL=UnstyledButton.module-B7YD8bFL.js.map
