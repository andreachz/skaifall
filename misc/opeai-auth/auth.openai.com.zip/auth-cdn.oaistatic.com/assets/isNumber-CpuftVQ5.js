import{b as e}from"./_baseGetTag-DBIYhhxi.js";import{i as t}from"./isObjectLike-nLWjQ9zq.js";var b="[object Number]";function o(r){return typeof r=="number"||t(r)&&e(r)==b}export{o as i};
//# sourceMappingURL=isNumber-CpuftVQ5.js.map
