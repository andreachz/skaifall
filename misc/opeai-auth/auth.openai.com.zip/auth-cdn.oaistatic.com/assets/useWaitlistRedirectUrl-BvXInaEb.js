import{z as t}from"./useAppNameEnum-B_RCZZaG.js";import{u as i}from"./useTypedDynamicConfig-CGyPrPvB.js";const e=t.object({redirect_url:t.string().default("")});function u(){const{redirect_url:r}=i("signup-waitlist-urls",e,{redirect_url:""});return r||null}export{u};
//# sourceMappingURL=useWaitlistRedirectUrl-BvXInaEb.js.map
