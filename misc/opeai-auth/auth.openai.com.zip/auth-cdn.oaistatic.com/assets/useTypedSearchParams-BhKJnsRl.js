import{g as m}from"./useAppNameEnum-B_RCZZaG.js";function u(s,r){const[e,t]=m(),a=s.safeParse(Object.fromEntries(e)),c=t;return[a.success?a.data:r,c]}export{u};
//# sourceMappingURL=useTypedSearchParams-BhKJnsRl.js.map
