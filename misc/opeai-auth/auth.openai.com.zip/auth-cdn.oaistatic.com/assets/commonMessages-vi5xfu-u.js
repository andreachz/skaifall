function a(t,e){return t.formatMessage({id:"thirdPartyLoginSubtitle",defaultMessage:`{app, select,
      whatsapp {to link your account to WhatsApp}
      other {to link your account}
    }`,description:"Subtitle on a page where the user can log into an account or create a new one that shows an external app that the user will connect their account to. The page this is shown on could be a login page with a title like 'Welcome back' or an account creation page with a title like 'Create an account'."},{app:e})}export{a as g};
//# sourceMappingURL=commonMessages-vi5xfu-u.js.map
