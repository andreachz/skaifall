const o="https://auth-cdn.oaistatic.com/assets/openai-logo-BAERmtuq.svg";export{o};
//# sourceMappingURL=openai-logo-Cr44hqyW.js.map
