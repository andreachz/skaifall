import{lU as n}from"./dmck639k4dv7claj.js";import"./cs7toih8jegb7teq.js";function e(){return null}const i=n(function(){return null});export{e as clientLoader,i as default};
//# sourceMappingURL=l9cxka3g8m3zanj4.js.map
