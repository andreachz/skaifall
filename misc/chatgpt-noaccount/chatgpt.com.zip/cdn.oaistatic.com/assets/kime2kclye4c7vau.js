const s="https://cdn.oaistatic.com/assets/team-upsell-mjqpjoww.webp",t={src:s};export{t as T};
//# sourceMappingURL=kime2kclye4c7vau.js.map
