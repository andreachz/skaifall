function t(e){const n=Object.values(e);return c=>n.includes(c)}export{t as c};
//# sourceMappingURL=iej0cupg2dqkmejt.js.map
