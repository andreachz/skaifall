import{c as f,r as c}from"./cs7toih8jegb7teq.js";const i=t=>{"use forget";const e=f.c(3),o=c.useRef(void 0);let r,s;return e[0]!==t?(r=()=>{o.current=t},s=[t],e[0]=t,e[1]=r,e[2]=s):(r=e[1],s=e[2]),c.useEffect(r,s),o};export{i as u};
//# sourceMappingURL=ljj1p3s92okaif60.js.map
