import{z as e}from"./dmck639k4dv7claj.js";const s="text-token-text-secondary inline-flex items-center rounded-full bg-[#f4f4f4] select-none dark:bg-token-main-surface-secondary",t=e(s," h-[22px] px-2 text-[0.5em] font-medium"),a=e(s,"h-[25px] px-3 text-xs");export{a as l,t as s};
//# sourceMappingURL=mgmoe87nocb640xb.js.map
