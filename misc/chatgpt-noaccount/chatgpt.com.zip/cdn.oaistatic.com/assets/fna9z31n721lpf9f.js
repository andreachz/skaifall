const t="_tableContainer_1rjym_1",e="_tableWrapper_1rjym_13",a={tableContainer:t,tableWrapper:e};export{a as t};
//# sourceMappingURL=fna9z31n721lpf9f.js.map
