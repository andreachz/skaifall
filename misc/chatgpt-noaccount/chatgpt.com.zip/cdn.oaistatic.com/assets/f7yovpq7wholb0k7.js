import{V as t,L as o}from"./dmck639k4dv7claj.js";function r(e){t.setItem(o.ConnectorOAuthFlowType,e)}function l(){const e=t.getItem(o.ConnectorOAuthFlowType);return e?(t.removeItem(o.ConnectorOAuthFlowType),e):null}export{l as g,r as s};
//# sourceMappingURL=f7yovpq7wholb0k7.js.map
