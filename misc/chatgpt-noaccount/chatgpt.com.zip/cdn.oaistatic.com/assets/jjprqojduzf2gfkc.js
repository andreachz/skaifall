import{e as n,jz as t,nZ as m,lw as i,n_ as a,eo as l,lk as p}from"./dmck639k4dv7claj.js";import{r as C}from"./cs7toih8jegb7teq.js";function x(){const r=n(),o=t(),e=C.useMemo(()=>o?new i(a(),r):new m(r),[o,r]),s=l(p(e));return{composerController:e,isComposerEmpty:s}}export{x as u};
//# sourceMappingURL=jjprqojduzf2gfkc.js.map
