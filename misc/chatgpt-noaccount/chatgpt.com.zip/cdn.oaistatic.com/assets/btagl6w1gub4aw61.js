function t(e){if(e)return`textdoc-message-${e}`}export{t as g};
//# sourceMappingURL=btagl6w1gub4aw61.js.map
