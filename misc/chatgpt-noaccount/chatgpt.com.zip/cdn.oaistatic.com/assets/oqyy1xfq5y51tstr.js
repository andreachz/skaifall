class s extends Worker{constructor(e,r){const t=String(e);super(t.includes("://")&&!t.startsWith(location.origin)?URL.createObjectURL(new Blob([`import("${t}")`],{type:"text/javascript"})):e,r)}}export{s as L};
//# sourceMappingURL=oqyy1xfq5y51tstr.js.map
