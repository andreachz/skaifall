const a="https://chatgpt.com/canvas/shared/";function s(t){return`${a}${t}`}export{a as S,s as g};
//# sourceMappingURL=bk8slwxjkdlmxjxm.js.map
