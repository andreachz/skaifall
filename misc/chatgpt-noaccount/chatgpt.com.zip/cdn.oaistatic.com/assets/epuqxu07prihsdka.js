import{r}from"./cs7toih8jegb7teq.js";var a=r.useLayoutEffect;export{a as i};
//# sourceMappingURL=epuqxu07prihsdka.js.map
